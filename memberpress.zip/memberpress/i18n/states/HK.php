<?php
/**
 * Hong Kong states
 */
$states['HK'] = array(
  'HONG KONG'       => _x('Hong Kong Island', 'ui', 'memberpress'),
  'KOWLOON'         => _x('Kowloon', 'ui', 'memberpress'),
  'NEW TERRITORIES' => _x('New Territories', 'ui', 'memberpress')
);

