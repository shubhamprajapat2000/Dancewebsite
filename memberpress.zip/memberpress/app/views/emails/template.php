<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" "http://www.w3.org/TR/REC-html40/loose.dtd">
<html>
  <head>
    <meta http-equiv="Content-Type" content="text/html;UTF-8">
  </head>
  <body style="background: #efefef; font: 13px 'Lucida Grande', 'Lucida Sans Unicode', Tahoma, Verdana, sans-serif; padding: 5px 0 10px" bgcolor="#efefef">
    <style type="text/css">
    body {
      font: 13px "Lucida Grande", "Lucida Sans Unicode", Tahoma, Verdana, sans-serif; background-color: #efefef; padding: 5px 0 10px 0;
    }
    </style>

    <?php echo $body; ?>
  </body>
</html>

