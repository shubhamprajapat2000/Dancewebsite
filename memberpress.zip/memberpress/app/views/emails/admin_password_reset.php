<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>
<p>
  <!-- translators: In this string, %1$s is the user's username -->
  <?php _ex('Password Lost and Changed for user ' . $username, 'ui', 'memberpress'); ?>
</p>
