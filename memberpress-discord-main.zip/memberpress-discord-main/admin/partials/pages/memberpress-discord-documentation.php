<div class="ets-tutor">
	<ul>
		<li>
			<label><?php echo __( 'YouTube video tutorial on how to connect the plugin with discord server', 'memberpress-discord-add-on' ); ?>
			</label>
			<a href="https://www.youtube.com/watch?v=2eHgq5BvDpU" target="_blank" ><?php echo __( 'Click Here', 'memberpress-discord-add-on' ); ?> <i class="fa fa-mouse-pointer" aria-hidden="true"></i></a>  
		</li>
		<li>
			 <label><?php echo __( 'Step-by-Step Written guide on how to connect the plugin with Discord server', 'memberpress-discord-add-on' ); ?>
			</label>
			<a href=" https://www.expresstechsoftwares.com/step-by-step-documentation-guide-on-how-to-connect-memberpress-and-discord-server-using-discord-addon" target="_blank" ><?php echo __( 'Click Here', 'memberpress-discord-add-on' ); ?> <i class="fa fa-mouse-pointer" aria-hidden="true"></i></a>
		</li>
		<li>
			<label><?php echo __( 'Features and other documentation', 'memberpress-discord-add-on' ); ?>
			</label>
			<a href="https://www.expresstechsoftwares.com/memberpress-discord-add-on/" target="_blank" ><?php echo __( 'Click Here', 'memberpress-discord-add-on' ); ?> <i class="fa fa-mouse-pointer" aria-hidden="true"></i></a>  
		</li>
	</ul>
</div>
